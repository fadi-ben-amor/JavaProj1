package metier;

public class Employer {
		public static int emp_id;
		public static String empUserName;
		int id,phone_number,nb_cin ;
		String name, first_name,username,password,team,Start_date;
		
		
		public Employer()
		{
			
		}
		public Employer(  String name, String first_name,int nb_cin, String start_date,String username, String password,int phone_number,  String team) {
		    this.phone_number = phone_number;
		    this.nb_cin = nb_cin;
		    this.name = name;
		    this.first_name = first_name;
		    this.username = username;
		    this.password = password;
		    this.team = team;
		    this.Start_date = start_date;
		}
		
		public int getId() {
		    return id;
		}
		public void setId(int id) {
		    this.id = id;
		}
		public int getPhone_number() {
		    return phone_number;
		}
		public void setPhone_number(int phone_number) {
		    this.phone_number = phone_number;
		}
		public int getNb_cin() {
		    return nb_cin;
		}
		public void setNb_cin(int nb_cin) {
		    this.nb_cin = nb_cin;
		}
		public String getName() {
		    return name;
		}
		public void setName(String name) {
		    this.name = name;
		}
		public String getFirst_name() {
		    return first_name;
		}
		public void setFirst_name(String first_name) {
		    this.first_name = first_name;
		}
		public String getUsername() {
		    return username;
		}
		public void setUsername(String username) {
		    this.username = username;
		}
		public String getPassword() {
		    return password;
		}
		public void setPassword(String password) {
		    this.password = password;
		}
		public String getTeam() {
		    return team;
		}
		public void setTeam(String team) {
		    this.team = team;
		}
		public String getStart_date() {
		    return Start_date;
		}
		public void setStart_date(String start_date) {
		    this.Start_date = start_date;
		}

		
	
		

}
