package metier;

public class Temp {
 private int idEm;
 private String emplUserName;
 private String entrer;
private String sortie;
public int getId() {
	return idEm;
}
public void setId(int id) {
	this.idEm = id;
}
public String getEmplUserName() {
	return emplUserName;
}
public void setEmplUserName(String emplUserName) {
	this.emplUserName = emplUserName;
}
public String getDateEntrer() {
	return entrer;
}
public void setDateEntrer(String dateEntrer) {
	this.entrer = dateEntrer;
}
public String getDateSortie() {
	return sortie;
}
public void setDateSortie(String dateSortie) {
	this.sortie = dateSortie;
}
public Temp(int id, String emplUserName, String entrer, String sortie) {
	this.idEm = id;
	this.emplUserName = emplUserName;
	this.entrer = entrer;
	this.sortie = sortie;
}
public Temp() {
	
}
 


}