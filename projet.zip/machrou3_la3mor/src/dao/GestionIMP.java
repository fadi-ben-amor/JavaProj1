package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
	
import metier.Employer;
import metier.Temp;

public class GestionIMP implements IGestion  {

	@Override
	public void addEmployer(Employer p) {		
		
		Connection cx =SingletonConnection.getConnection();  //faire_l'appel_�_la_m�thode_Singleton
		try {
			PreparedStatement st = cx.prepareStatement("insert into t_employer(id,name,first_name,nb_cin,Start_date,username,password,phone_number,team) values (?,?,?,?,?,?,?,?,?)");
			st.setInt(1,p.getId());
			st.setString(2,p.getName());
			st.setString(3,p.getFirst_name());	
			st.setInt(4,p.getNb_cin());
			st.setString(5,p.getStart_date());
			st.setString(6,p.getUsername());
			st.setString(7,p.getPassword());
			st.setInt(8,p.getPhone_number());
			st.setString(9,p.getTeam());


			st.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} }
	
	
	@Override
	public List<Employer> getAllEmployers() {
		// TODO Auto-generated method stub
		
		Connection cx =SingletonConnection.getConnection();  //faire_l'appel_�_la_m�thode_Singleton
		List<Employer>liste=new ArrayList<>();  //cr�er_une_liste_qui_va_contenir_les_cat�gories
		try {
			PreparedStatement ps = cx.prepareStatement("select * from t_employer"); //preparer_la_requete
			ResultSet rs =ps.executeQuery(); //executer_la_requ�te
			while (rs.next()) {
				Employer e = new Employer();  //creer_une_ca);
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setFirst_name(rs.getString(3));
				e.setNb_cin(rs.getInt(4));
				e.setStart_date(rs.getString(5));
				e.setUsername(rs.getString(6));
				e.setPassword(rs.getString(7));
				e.setPhone_number(rs.getInt(8));
				e.setTeam(rs.getString(9));
				 
				liste.add(e); //ajouter_�la_liste
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return liste;

	}

	/*@Override
	public List<Employer> getProduitPC(int CIN) {
		// TODO Auto-generated method stub
		return null;
	}*/

	public void modifier(Employer p) {
		Connection cx =SingletonConnection.getConnection();
        try {
            PreparedStatement st= cx.prepareStatement("update t_employer set name=?, first_name=?, nb_cin=?, Start_date=?, username=? ,password=?,phone_number=?,team=? where id=?");
            st.setInt(9,p.getId());
			st.setString(1,p.getName());
			st.setString(2,p.getFirst_name());	
			st.setInt(3,p.getNb_cin());
			st.setString(4,p.getStart_date());
			st.setString(5,p.getUsername());
			st.setString(6,p.getPassword());
			st.setInt(7,p.getPhone_number());
			st.setString(8,p.getTeam());
            st.executeUpdate();
        }catch(SQLException e1){
            e1.printStackTrace();
        }

    }

    @Override
    public void deleteEmployer(int id) {
        Connection cx=SingletonConnection.getConnection();
        try {
            PreparedStatement st= cx.prepareStatement("delete from t_employer where id=?");
                st.setInt(1, id);
                st.executeUpdate();
        }catch(SQLException e1){
            e1.printStackTrace();
        }

    }


	@Override
	public void entre() {
		Connection cx =SingletonConnection.getConnection();  //faire_l'appel_�_la_m�thode_Singleton
	
		try {
			PreparedStatement st = cx.prepareStatement("insert into temp(userEmp,start_time, employerID) values (?,?,?)");
			LocalDateTime localDate =LocalDateTime.now();
			DateFormat df = new SimpleDateFormat("yyyy-mm-dd  hh:mm:ss");  
            String dat = df.format(localDate); 
			//DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			//Date date = new Date(0);
            
			st.setString(1,Employer.empUserName);
			//st.setString(2,strDate);
			//st.setString(3,strDate);
			st.setString(2,dat );
			st.setInt(3, Employer.emp_id);
			

			st.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} 
		
	}


	@Override
	public void sortie() {
Connection cx =SingletonConnection.getConnection();  //faire_l'appel_�_la_m�thode_Singleton
		
		try {
			PreparedStatement st = cx.prepareStatement("insert into temp(userEmp,end_time, employerID) values (?,?,?)");
			LocalDateTime localDate =LocalDateTime.now();
			DateFormat df = new SimpleDateFormat("yyyy-mm-dd  hh:mm:ss");  
            String dat = df.format(localDate); 
			//DateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			//Date date = new Date(0);
            
			st.setString(1,Employer.empUserName);
			//st.setString(2,strDate);
			//st.setString(3,strDate);
			st.setString(2,dat );
			st.setInt(3, Employer.emp_id);
			

			st.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} 
		
	}
	@Override
	public List<Temp> getTemp() {
		// TODO Auto-generated method stub
		
		Connection cx =SingletonConnection.getConnection();  //faire_l'appel_�_la_m�thode_Singleton
		List<Temp>liste=new ArrayList<>();  //cr�er_une_liste_qui_va_contenir_les_cat�gories
		try {
			PreparedStatement ps = cx.prepareStatement("select * from temp"); //preparer_la_requete
			ResultSet rs =ps.executeQuery(); //executer_la_requ�te
			while (rs.next()) {
				Temp e = new Temp();  //creer_une_ca);
				e.setId(rs.getInt(5));
				e.setEmplUserName(rs.getString(2));
				e.setDateEntrer(rs.getString(3));
				e.setDateSortie(rs.getString(4));
				 
				liste.add(e); //ajouter_�la_liste
			}
		}catch(SQLException ee) {
			ee.printStackTrace();
		}
		return liste;

	}
}