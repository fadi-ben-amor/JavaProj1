package dao;

import java.util.List;

import metier.Employer;
import metier.Temp;

public interface IGestion {
	
	public void addEmployer(Employer p);
	
	public List<Employer> getAllEmployers();
	
	//public List<Employer> getProduitPC(int CIN);
	
	public void modifier(Employer p);
	
	public void deleteEmployer(int id);

	public void entre();

	public void sortie();

	public  List<Temp> getTemp();
	
	//public void verif(String username);


}
