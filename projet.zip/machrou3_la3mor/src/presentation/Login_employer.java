package presentation;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import dao.GestionIMP;
import dao.IGestion;
import metier.Employer;

public class Login_employer extends JFrame   {
	JLabel t1=new JLabel("Username :");
	JTextField user=new JTextField("");
     JLabel  t2=new JLabel("Password :");
	JPasswordField pass= new JPasswordField("");
	JButton login =new JButton("login");
	JButton ac =new JButton("accueil");
	 JPanel  p1 = new JPanel (new GridLayout(3,2,10,10));
	 
	 IGestion action =new GestionIMP();
	Login_employer(){
		this.setTitle("identifiez vous s'il vous pla�t !");
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(250,150);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		p1.add(t1);
		p1.add(user);
		p1.add(t2);
		p1.add(pass);
		p1.add(ac);
		p1.add(login);
		this.add(p1);
		login.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if (user.getText().equals("")|| pass.getText().equals(""))
							JOptionPane.showMessageDialog(Login_employer.this, " fill user and password ","eurreur ", JOptionPane.INFORMATION_MESSAGE);
						else {
							List<Employer> a = new ArrayList<>();
		    				a=action.getAllEmployers();
		    				int j=0;
		    				for (Employer s : a) {
		    					if(user.getText().equals(s.getUsername()) && pass.getText().equals(s.getPassword())) {
		    						j=1;
		    						Employer.emp_id = s.getId();
		    						Employer.empUserName = s.getUsername();
		    					}
		    				}
		    				
		    				if (j == 1) {
		    					new  Employer_page();
								dispose();
							}else {
								JOptionPane.showMessageDialog(Login_employer.this, " unauthorized user ","eurreur ", JOptionPane.INFORMATION_MESSAGE);
							}
						
					}}
				});
		ac.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 new  Accueil();
			}
		});
	}
	 public static void main(String[] args) {
	      new Login_employer();
	   }
}