package presentation;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import metier.Employer;

public class tableModele    extends AbstractTableModel {
	List<Employer> employers=new ArrayList<>();
	String titre[] = { "id","Name","first name","nb_cin","Start_date","username","password","phone_number","team" };
		

	@Override
	public int getRowCount() {
		
		return employers.size();
}
	
	@Override 
	public String getColumnName(int column) {
		//TODO AUTO-generated method stub
		return titre[column];
	}
	public void chargerTable(List<Employer> liste) {
		employers=liste;
		fireTableDataChanged();
	}


	 @Override
		public int getColumnCount() {
			
			return titre.length;
		}

	 @Override
		public Object getValueAt(int l, int c) {
		 switch (c) {
	        case 0 :
				return employers.get(l).getId();
	        case 1:
	            return employers.get(l).getName();
	        case 2:
	            return employers.get(l).getFirst_name();
	        case 3:
	            return employers.get(l).getNb_cin();
	        case 4:
	            return employers.get(l).getStart_date();
	        case 5:
	            return employers.get(l).getUsername();
	        case 6:
	            return employers.get(l).getPassword();
	        case 7:
	            return employers.get(l).getPhone_number(); 
	        case 8:
	            return employers.get(l).getTeam(); 
	        }
		 return null ;
		
	}
	
}