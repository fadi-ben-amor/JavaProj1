package presentation;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Admin_page extends JFrame {
	JButton gemp = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\gestion.png"));
	JButton log = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\history.png"));
	JButton logout = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\logout.png"));
	public Admin_page() {
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle("Page d'Administration");
		this.setLayout(new GridLayout(1, 3, 10, 10));
		this.add(gemp);
		this.add(log);
		this.add(logout);
		this.setSize(600,300);
		this.setLocationRelativeTo(null);
		gemp.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddEmployer();
				dispose();
			}
		});
		log.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new log();
				dispose();
			}
		});
		logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				new Accueil();
				dispose();
			}
		});
		
	}
}
