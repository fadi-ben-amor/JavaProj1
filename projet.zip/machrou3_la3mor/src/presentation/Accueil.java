package presentation;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Accueil extends JFrame {
	JButton employer = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\employer.png"));
	JButton admin = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\admin.png"));
	JButton quitter = new JButton(new ImageIcon("C:\\Users\\Fadi\\Desktop\\machrou3_la3mor0\\res\\close.jpg"));
	JLabel empspace=new JLabel("Employer Space:");
	JLabel adminspace=new JLabel("Admin Space:");
	JLabel exit=new JLabel("Exit:");
	JPanel p1 = new JPanel(new GridLayout(2,1));
	JPanel p2 = new JPanel(new GridLayout(2,1));
	JPanel p3 = new JPanel(new GridLayout(2,1));

	public Accueil() {
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setTitle("Accueil");
		this.setLayout(new GridLayout(1, 3,10,10));
		this.add(p1);
		this.add(p2);
		this.add(p3);
		p1.add(empspace);
		p2.add(adminspace);
		p3.add(exit);

		p1.add(employer);
		p2.add(admin);
		p3.add(quitter);
		this.setSize(400,300);
		setLocationRelativeTo(null);
		//les bordeurs 
		
	    p1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black,1),""));
	    p2.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black,1),""));
	    p3.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black,1),""));

	    p1.setBackground(Color.lightGray);
	    p2.setBackground(Color.lightGray);
	    p3.setBackground(Color.lightGray);


		employer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Login_employer();
				dispose();
				
				
			}
		});
		admin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Login_admin();
				dispose();
			}
		});
		quitter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
	}
	public static void main(String[] args) {
		new Accueil();
		
	}
}