package presentation;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import dao.GestionIMP;
import dao.IGestion;

public class log extends JFrame{
	JPanel p2 = new JPanel(new GridLayout(1,2))  ;
	JButton r = new JButton("Return");
	JButton log_out = new JButton("Logout");
	
	Tablelog tm=new Tablelog();
	JTable table = new JTable(tm);
	JScrollPane jsp= new JScrollPane(table);
public log() {
	
	this.setVisible(true);
	this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	this.setTitle("INs and OUTs");
	this.add(jsp);
	p2.add(r);
	p2.add(log_out);
	
	this.add(p2,BorderLayout.SOUTH);
	setLocationRelativeTo(null);
	this.setSize(400,300);
	
	IGestion action =new GestionIMP();
	
	
	tm.chargerTable(action.getTemp());
	 r.addActionListener(new ActionListener() {
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		 new  Admin_page();
	    			dispose();
	    	}
	    });
	 log_out.addActionListener(new ActionListener() {
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		 new  Accueil();
	    			dispose();
	    	}
	    });

	 
	 
	
	
}
public static void main(String[] args) {
	new log();
}
}
