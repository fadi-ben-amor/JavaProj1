package presentation;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Login_admin extends JFrame  {
	JLabel t3=new JLabel("Bonjour Monsieur Fadi & Madam Nour !");
	JLabel t1=new JLabel("Username :");
	JTextField user=new JTextField("");
	
     JLabel  t2=new JLabel("Password :");
	JPasswordField pass= new JPasswordField("");
	
	JButton login =new JButton("login");
	JButton ac =new JButton("accueil");
	
	 JPanel  p1 = new JPanel (new GridLayout(3,2,10,10));
   Login_admin() {
	   this.setTitle("identifiez vous s'il vous pla�t !");
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(250,200);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.add(t3);
		p1.add(t1);
		p1.add(user);
		p1.add(t2);
		p1.add(pass);
		p1.add(ac);
		p1.add(login);
		
		this.add(p1);

	login.addActionListener(new ActionListener()
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			if (user.getText().equals("")|| pass.getText().equals(""))
				JOptionPane.showMessageDialog(null, "Please Fill Username and Password","Your Fields are Empty ", JOptionPane.INFORMATION_MESSAGE);
			else if(user.getText().equals("admin")&& pass.getText().equals("admin") ){
				new  Admin_page();
				dispose();
			}
			else {
				JOptionPane.showMessageDialog(null, "User Is Not An Admin","Access Denied ", JOptionPane.INFORMATION_MESSAGE);
			}	
		}
	});
	ac.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			 new  Accueil();
				dispose();
		}
	});}
   public static void main(String[] args) {
      new Login_admin();
   }
}