
package presentation;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import metier.Employer;
import metier.Temp;

public class Tablelog extends AbstractTableModel {
	List<Temp> temp=new ArrayList<>();
	String titre[] = { "id","UserName","Started at :","Left at :" };
		

	@Override
	public int getRowCount() {
		
		return temp.size();
}
	
	@Override 
	public String getColumnName(int column) {
		//TODO AUTO-generated method stub
		return titre[column];
	}
	public void chargerTable(List<Temp> liste) {
		temp = liste;
		fireTableDataChanged();
	}


	 @Override
		public int getColumnCount() {
			
			return titre.length;
		}

	 @Override
		public Object getValueAt(int l, int c) {
		 switch (c) {
	        case 0 :
				return temp.get(l).getId();
	        case 1:
	            return temp.get(l).getEmplUserName();
	        case 2:
	            return temp.get(l).getDateEntrer();
	        case 3:
	            return temp.get(l).getDateSortie();
	        
	     }
		 return null ;
		
	}
	
}
