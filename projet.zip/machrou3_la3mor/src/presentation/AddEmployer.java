package presentation;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import dao.IGestion;
import dao.GestionIMP;
import metier.Employer;

public class AddEmployer  extends JFrame {
	
	JLabel t1= new JLabel ("Enter employer name please  :");
	JTextField  nom= new JTextField ("");
	JLabel t2= new JLabel ("Enter employer first name please  :");
	JTextField  prenom = new JTextField ("");
	JLabel t3= new JLabel ("Enter employer's CIN number please  :");
	JTextField  cin= new JTextField ("");
	JLabel t4= new JLabel ("Wrtie the date when the employer start working please  :");
	JTextField DateStart= new JTextField ("");
    JLabel t5 = new JLabel("Write his username  :");
    JTextField user= new JTextField("");
    JLabel t6 = new JLabel("Password:");
    JPasswordField pass= new JPasswordField("");
    JLabel t7 = new JLabel("Phone number  :");
    JTextField number= new JTextField("");
    JLabel t8 = new JLabel("Team :");
    JTextField team= new JTextField("");
    JLabel td = new JLabel("i want to modify/delete line with id :");
    JTextField tfd= new JTextField("");
    JButton  addemp= new JButton("add employer");
    JButton  retour= new JButton("Return");
    JButton  delete= new JButton("Delete");
    JButton  edit= new JButton("Edit");

	IGestion action =new GestionIMP();
	
	tableModele tm=new tableModele();
	JTable table = new JTable(tm);
	JScrollPane jsp=new JScrollPane(table); 
	Object [] columns = {"id","name","first name","CIN","Start Date","username","password","phone number","team"};
    
    JPanel p0= new JPanel( new GridLayout(1,2));
    JPanel p1= new JPanel ( new GridLayout(11,2));
   // JPanel p2= new JPanel ( new GridLayout(0,2));
    //JPanel p3= new JPanel ( new BorderLayout());
    public  AddEmployer(){
      //  this.setLayout( new GridLayout(1,2));
        p0.add(p1);
        //p0.add(p2);
        this.add(p0);
        p1.add(t1);
        p1.add(nom);
        p1.add(t2);
        p1.add(prenom);
        p1.add(t3);
        p1.add(cin);
        p1.add(t4);
        p1.add(DateStart);
        p1.add(t5);
        p1.add(user);
        p1.add(t6);
        p1.add(pass);
        p1.add(t7);
        p1.add(number);
        p1.add(t8);
        p1.add(team);
        p1.add(td);
        p1.add(tfd);
       // p1.add(p2,BorderLayout.CENTER);
        p1.add(retour);
        p1.add(addemp);
        p1.add(delete);
        p1.add(edit);
        p0.add(jsp);
          
      
        this.setTitle("Add Employer");
        //this.setLocationRelativeTo(null);
    	this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	this.pack();
    	this.setVisible(true);        
		tm.chargerTable(action.getAllEmployers());


    retour.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e) {
    		 new  Admin_page();
    			dispose();
    	}
    });
    
    table.addMouseListener(new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseClicked(MouseEvent e) {
			if (table.getSelectedRow() != -1) {
				int row = table.getSelectedRow();
    			nom.setText(table.getModel().getValueAt(row, 1).toString());
    			prenom.setText(table.getModel().getValueAt(row, 2).toString());
    			cin.setText(table.getModel().getValueAt(row, 3).toString());
    			DateStart.setText(table.getModel().getValueAt(row, 4).toString());
    			user.setText(table.getModel().getValueAt(row, 5).toString());
    			pass.setText(table.getModel().getValueAt(row, 6).toString());
    			number.setText(table.getModel().getValueAt(row, 7).toString());
    			team.setText(table.getModel().getValueAt(row, 8).toString());
    			tfd.setText(table.getModel().getValueAt(row, 0).toString());


    		
			}
			
		}
	});
    
    addemp.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e) {
    		String no=nom.getText();
    		String pr=prenom.getText();
    		String nume=number.getText();
    		String nci=number.getText();
    		int n=Integer.parseInt(number.getText());
    		int c=Integer.parseInt(cin.getText());
    		String ds=DateStart.getText();
    		String us=user.getText();
    		String pw=pass.getText();
    		String tea=team.getText();
    		if(( no.equals("")) ||  ( pr.equals(""))  ||  ( nci.equals("")) 
    				|| (ds.equals("")) || (us.equals("")) || 
    				(pw.equals("")) || (nume.equals("")) || (tea.equals(""))) 
    			JOptionPane.showMessageDialog(AddEmployer.this, "please fill informations");
    		
    		else {
    				List<Employer> a = new ArrayList<>();
    				a=action.getAllEmployers();
    				int j=0;
    				for (Employer s : a) {
    					if(us.equals(s.getUsername())) {
    						j=1;
    					}
    				}
    				if(j==0) {
    					action.addEmployer(new Employer(no, pr,c,ds,us,pw,n,tea));
    					tm.chargerTable(action.getAllEmployers());
    	    			JOptionPane.showMessageDialog(AddEmployer.this, "Employer Added");
    				}
    				else {
    	    			JOptionPane.showMessageDialog(AddEmployer.this, "User taken by another employer");
    				}}}});
    delete.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e) {
    		int id=Integer.parseInt(tfd.getText());
    		 action.deleteEmployer(id);
				tm.chargerTable(action.getAllEmployers());
    	}
    });
    edit.addActionListener(new ActionListener() {
    	@Override
    	public void actionPerformed(ActionEvent e) {
    		int id = Integer.parseInt(tfd.getText());
    		String no = nom.getText();
    		String pr = prenom.getText();
    		int c = Integer.parseInt(cin.getText());
    		String date = DateStart.getText();
    		String uer = user.getText();
    		String passe = pass.getText();
    		int numP = Integer.parseInt(number.getText());
    		String tea = team.getText();
    		
            Employer p = new Employer();
            p.setId(id);
            p.setName(no);
            p.setFirst_name(pr);
            p.setPhone_number(numP);
            p.setNb_cin(c);
            p.setStart_date(date);
            p.setUsername(uer);
            p.setPassword(passe);
            p.setTeam(tea);
            action.modifier(p);
            tm.chargerTable(action.getAllEmployers());
        }
    });
			
    	
    
    
}
   
    
    		
public static void main(String[] args) {
	new AddEmployer();
}
    
}