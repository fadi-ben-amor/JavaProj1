package presentation;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import dao.GestionIMP;
import dao.IGestion;

public class Employer_page extends JFrame{

	Calendar Calendar ;
	SimpleDateFormat timeFormat;
	SimpleDateFormat dayFormat;
	JLabel timeLabel;
	JLabel dayLabel;
	String time;
	String day;
	String msg;
	JPanel p1 = new JPanel(new GridLayout(1,3,5,5));
	JPanel p2 = new JPanel(new GridLayout(1,3,5,5));
	JPanel p3 = new JPanel(new GridLayout(1,1,5,5));

	JLabel conf=new JLabel ("");
	JButton ebtn = new JButton ("entrer");
	JButton sbtn = new JButton ("sortir");
	JButton exitbtn = new JButton ("quitter");
	JButton go = new JButton ("reload");
	IGestion action =new GestionIMP();
	Employer_page(){
		
		this.setTitle("Marquez votre pr�sence !");
		this.setSize(800,300);
		setLayout(new GridLayout(3, 1));
		timeFormat = new SimpleDateFormat("hh:mm:ss a");
		dayFormat = new SimpleDateFormat("d/M/y");
		timeLabel = new JLabel();
		timeLabel.setFont(new Font("Verdana",Font.PLAIN,50));
		timeLabel.setForeground(new Color(0x00FF00));
		timeLabel.setBackground(Color.black);
		timeLabel.setOpaque(true);	
		dayLabel = new JLabel();
		dayLabel.setFont(new Font("Verdana",Font.PLAIN,50));
		dayLabel.setForeground(new Color(0x00FF00));
		dayLabel.setBackground(Color.black);
		dayLabel.setOpaque(true);
		this.setVisible(true);
		p1.add(timeLabel);
		p1.add(dayLabel);
		p2.add(ebtn);
		p2.add(sbtn);
		p2.add(exitbtn);
		p2.add(go);
		p3.add(conf);
		this.add(p1);
		this.add(p2);
		this.add(p3);
		setTime();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);}
		
		public void setTime() {
			

			exitbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				new Accueil();
				dispose();
			}
		});
		ebtn.addActionListener(new ActionListener() {
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		// TODO Auto-generated method stub
	    		conf.setText("Vous avez sign� l'entr�e , Bonne journ�e !");
	    		action.entre();

	    	}
	    });
		sbtn.addActionListener(new ActionListener() {
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		// TODO Auto-generated method stub
	    		conf.setText("Vous avez sign� la sortie , Bonne nuit !");
	    		action.sortie();

	    	}
	    });
		go.addActionListener(new ActionListener() {
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		// TODO Auto-generated method stub
	    		
	    		time = timeFormat.format(Calendar.getInstance().getTime());
				timeLabel.setText(time);
				day = dayFormat.format(Calendar.getInstance().getTime());
				dayLabel.setText(day);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
				}
	    });
		//while (true) {
	
			time = timeFormat.format(Calendar.getInstance().getTime());
			timeLabel.setText(time);
			day = dayFormat.format(Calendar.getInstance().getTime());
			dayLabel.setText(day);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		
		
		
		
		//}
		
	public static void main(String[] args) {
	    new Employer_page();
	}
	
}